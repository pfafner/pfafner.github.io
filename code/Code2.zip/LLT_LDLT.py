import numpy as np
from scipy import linalg as lg


def Cholesky(A):
    m, n = A.shape
    if (m != n):
        raise Exception('matrix is not square')
    elif not np.all(A.T == A):
        raise Exception('matrix is not symmetric')
    else:
        R = A.copy()
    
        for k in range(0, n):
            #print('Paso columna {}: \n'.format(j+1))
            if (R[k,k] <= 0):
                raise Exception('matrix is not positive definite')
            else:
                for j in range(k+1, n):
                    R[j,k:n] = R[j,k:n] - (R[k,j] / R[k,k]) * R[k,k:n]
                R[k,k:n] = R[k,k:n] / np.sqrt(R[k,k])
                #print(R, end='\n\n')
    return R



def LDLt(A):
    m, n = A.shape
    if (m != n):
        raise Exception('matrix is not square')
    elif not np.all(A.T == A):
        raise Exception('matrix is not symmetric')
    else:
        R = A.copy()
        D = np.eye(n)
    
        for k in range(0, n):
            #print('Paso columna {}: \n'.format(j+1))
            if (R[k,k] <= 0):
                raise Exception('matrix is not positive definite')
            else:
                D[k,k] = R[k,k]
                for j in range(k+1, n):
                    R[j,k:n] = R[j,k:n] - (R[k,j] / D[k,k]) * R[k,k:n]
                R[k,k:n] = R[k,k:n] / D[k,k]
                #print(R, end='\n\n')
                #print(D, end='\n\n')
    return R.T, D



