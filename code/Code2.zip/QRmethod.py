import numpy as np
import scipy.linalg as lg


def QRdecomp(A):
    n = A.shape[0]
    Q = np.zeros((n,n))
    R = np.zeros((n,n))
    V = A.copy()
    
    for i in range(0, n):
        v = V[:,i]
        R[i,i] = np.sqrt((v**2).sum())
        Q[:,i] = V[:,i] / R[i,i]
        for j in range(i+1, n):
            R[i,j] = Q[:,i] @ V[:,j]
            V[:,j] = V[:,j] - R[i,j] * Q[:,i]
    return Q, R


def QRbasico(A, eps=1e-3, maxI=100):
    Ak = A.copy()
    i = 0
    fin = 0
    Aold = A.copy()
    
    while not fin:
        Qk, Rk = QRdecomp(Ak)
        Ak = Rk @ Qk
        tol = np.abs(Ak-Aold).ravel().sum()
        if ((tol < eps) or (i >= maxI)):
            fin = 1
            print(i)
        i = i+1
        Aold = Ak
    return Ak


def QR(A, eps=1e-3, maxI=100):
    Ak = A.copy()
    i = 0
    fin = 0
    Qold = A.copy()
    Q = np.eye(A.shape[0])
    
    while not fin:
        Qk, Rk = QRdecomp(Ak)
        Ak = Rk @ Qk
        Q = Q @ Qk
        tol = np.abs(Qk-Qold).ravel().sum()
        if ((tol < eps) or (i >= maxI)):
            fin = 1
            print(i)
        i = i+1
        Qold = Qk
    return Q, Ak


def sign(x):
    return np.abs(x)/x


def Hessemberg(A):
    n = A.shape[0]
    H = A.copy()   
    for k in range(0, n-2):
        x = H[k+1:n, k]
        s = sign(x[0])
        e1 = np.zeros(x.shape)
        e1[0] = 1.
        v = s*np.linalg.norm(x,2)*e1 + x
        v = v / np.sqrt((v**2).sum())
        
        H[k+1:n, k:n] = H[k+1:n, k:n] - 2.* v.reshape(-1,1) @ (v.reshape(1,-1) @ H[k+1:n, k:n])
        H[:, k+1:n]   = H[:, k+1:n] - 2.*(H[:, k+1:n] @ v.reshape(-1,1)) @ v.reshape(1,-1)
    return H


def QRpractical(A, mu=0., eps=1e-3, maxI=100):
    Hk = Hessemberg(A)
    i = 0
    fin = 0
    Qold = Hk.copy()
    Q = np.eye(A.shape[0])
    I = np.eye(A.shape[0])
    
    while not fin:
        Qk, Rk = QRdecomp(Hk - mu*I)
        Hk = (Rk @ Qk) + mu*I
        Q = Q @ Qk
        tol = np.abs(Qk-Qold).ravel().sum()
        if ((tol < eps) or (i >= maxI)):
            fin = 1
            print(i)
        i = i+1
        Qold = Qk
    return Q, Hk
