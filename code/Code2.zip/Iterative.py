import numpy as np
import scipy.linalg as lg
import matplotlib.pyplot as plt


def Jacobi(A, b, x0, tol=1e-4, maxIter=100, out=False):
    ''' Apply the Jacobi iteration method for solving the system AX = b.
        Inputs:  A  = matrix of the system, as numpy array of shape (n,n),
                 b  = vector, as numpy array of shape (n,),
                 X0 = start point, as numpy array of shape (n,).
        Outputs: x = approximate solution, as numpy array of shape (n,).
    '''
    m, n = A.shape
    p = b.shape[0]
    q = x0.shape[0]
    if (m != n):
        raise Exception('matrix is not square')
    elif (n != p):
        raise Exception('shapes of A and b don\'t match')
    elif (n != q):
        raise Exception('shapes of A and x0 don\'t match')
    else:
        x = x0.copy()
        xold = x0.copy()
        fin = 0
        i = 0
        error = []
        sol = [x0]
        if(out == True): print('{:3d}: {}'.format(i, x))
        
        #main iteration
        while ((not fin) and (i <= maxIter)):
            for j in range(0, n):
                suma = 0.
                for k in range(0, n):
                    if (k != j):
                        suma += A[j,k] * xold[k]
                x[j] = (b[j] - suma) / A[j,j]
            
            #check error
            err = np.linalg.norm(x - xold, 2)
            if (err < tol):
                fin = 1
            xold = x.copy()
            sol.append(x)
            error.append(err)
            i = i+1
            if(out == True): print('{:3d}: {}'.format(i, x))
    return x, np.array(sol), np.array(error)
    

def Seidel(A, b, x0, tol=1e-4, maxIter=100, out=False):
    ''' Apply the Seidel iteration method for solving the system AX = b.
        Inputs:  A  = matrix of the system, as numpy array of shape (n,n),
                 b  = vector, as numpy array of shape (n,),
                 X0 = start point, as numpy array of shape (n,).
        Outputs: x = approximate solution, as numpy array of shape (n,).
    '''
    m, n = A.shape
    p = b.shape[0]
    q = x0.shape[0]
    if (m != n):
        raise Exception('matrix is not square')
    elif (n != p):
        raise Exception('shapes of A and b don\'t match')
    elif (n != q):
        raise Exception('shapes of A and x0 don\'t match')
    else:
        x = x0.copy()
        xold = x0.copy()
        fin = 0
        i = 0
        error = []
        sol = [x0]
        if(out == True): print('{:3d}: {}'.format(i, x))
        
        #main iteration
        while ((not fin) and (i <= maxIter)):
            for j in range(0, n):
                suma = 0.
                for k in range(0, j):
                    suma += A[j,k] * x[k]
                if (j < n-1):
                    for k in range(j+1, n):
                        suma += A[j,k] * xold[k]
                x[j] = (b[j] - suma) / A[j,j]
            
            #check error
            err = np.linalg.norm(x - xold, 2)
            if (err < tol):
                fin = 1
            xold = x.copy()
            sol.append(x)
            error.append(err)
            i = i+1
            if(out == True): print('{:3d}: {}'.format(i, x))
    return x, np.array(sol), np.array(error)


def JOR(A, b, x0, omega=1., tol=1e-4, maxIter=100, out=False):
    ''' Apply the Jacobi iteration method for solving the system AX = b.
        Inputs:  A  = matrix of the system, as numpy array of shape (n,n),
                 b  = vector, as numpy array of shape (n,),
                 X0 = start point, as numpy array of shape (n,).
        Outputs: x = approximate solution, as numpy array of shape (n,).
    '''
    m, n = A.shape
    p = b.shape[0]
    q = x0.shape[0]
    if (m != n):
        raise Exception('matrix is not square')
    elif (n != p):
        raise Exception('shapes of A and b don\'t match')
    elif (n != q):
        raise Exception('shapes of A and x0 don\'t match')
    elif ((omega <= 0.) or (omega >= 2.)):
        raise Exception('omega is out of range (0,2)')
    else:
        x = x0.copy()
        xold = x0.copy()
        fin = 0
        i = 0
        error = []
        sol = [x0]
        if(out == True): print('{:3d}: {}'.format(i, x))
        
        #main iteration
        while ((not fin) and (i <= maxIter)):
            for j in range(0, n):
                suma = 0.
                for k in range(0, n):
                    if (k != j):
                        suma += A[j,k] * xold[k]
                x[j] = omega*((b[j] - suma) / A[j,j]) + (1.-omega)*xold[j]
            
            #check error
            err = np.linalg.norm(x - xold, 2)
            if (err < tol):
                fin = 1
            xold = x.copy()
            sol.append(x)
            error.append(err)
            i = i+1
            if(out == True): print('{:3d}: {}'.format(i, x))
    return x, np.array(sol), np.array(error)


def SOR(A, b, x0, omega=1., tol=1e-4, maxIter=100, out=False):
    ''' Apply the Seidel iteration method for solving the system AX = b.
        Inputs:  A  = matrix of the system, as numpy array of shape (n,n),
                 b  = vector, as numpy array of shape (n,),
                 X0 = start point, as numpy array of shape (n,).
        Outputs: x = approximate solution, as numpy array of shape (n,).
    '''
    m, n = A.shape
    p = b.shape[0]
    q = x0.shape[0]
    if (m != n):
        raise Exception('matrix is not square')
    elif (n != p):
        raise Exception('shapes of A and b don\'t match')
    elif (n != q):
        raise Exception('shapes of A and x0 don\'t match')
    elif ((omega <= 0.) or (omega >= 2.)):
        raise Exception('omega is out of range (0,2)')
    else:
        x = x0.copy()
        xold = x0.copy()
        fin = 0
        i = 0
        error = []
        sol = [x0]
        if(out == True): print('{:3d}: {}'.format(i, x))
        
        #main iteration
        while ((not fin) and (i <= maxIter)):
            for j in range(0, n):
                suma = 0.
                for k in range(0, j):
                    suma += A[j,k] * x[k]
                if (j < n-1):
                    for k in range(j+1, n):
                        suma += A[j,k] * xold[k]
                x[j] = omega*((b[j] - suma) / A[j,j]) + (1.-omega)*xold[j]
            
            #check error
            err = np.linalg.norm(x - xold, 2)
            if (err < tol):
                fin = 1
            xold = x.copy()
            sol.append(x)
            error.append(err)
            i = i+1
            if(out == True): print('{:3d}: {}'.format(i, x))
    return x, np.array(sol), np.array(error)
    

def tridiag(n, a):
    X = np.zeros((n,n))
    aext = np.hstack([np.array(a), np.zeros(n-2)])
    for i in range(0, n):
        X[i] = np.roll(aext, shift=i-1)[:-1] 
    return X


def pentadiag(n, a):
    X = np.zeros((n,n))
    aext = np.hstack([np.array(a), np.zeros(n-3)])
    for i in range(0, n):
        X[i] = np.roll(aext, shift=i-2)[:-2] 
    return X
