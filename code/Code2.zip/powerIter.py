import numpy as np
import scipy.linalg as lg


def frobenius(A, eps=1e-3, maxI=100):
    n = A.shape[0]
    x = np.ones(n) / n
    eig = 1
    
    fin = 0
    i = 0
    while not fin:
        print('{:2d}: eig={}, x={}'.format(i, eig, x))
        xold = x.copy()
        y = A @ x
        eig = np.sqrt((y**2).sum() / (x**2).sum())
        x = y / np.sqrt((y**2).sum())
        if ((np.linalg.norm(x-xold, 1) < eps) or (i >= maxI)):
            fin = 1
        i += 1
    return eig, x



def frobenius2(A, eps=1e-3, maxI=100):
    n = A.shape[0]
    x = np.ones(n) / n
    eig = 1
    
    fin = 0
    i = 0
    while not fin:
        xold = x.copy()
        eigold = eig * 1.        
        y = A @ x
        x = y / np.sqrt((y**2).sum())
        eig = (x.T) @ A @ x
        if ((np.abs(eig-eigold) < eps) or (i >= maxI)):
        #if ((np.linalg.norm(x-xold, 1) < eps) or (i >= maxI)):
            fin = 1
        i += 1
    print(i, end=' ', flush=None)
    return eig, x



def frobeniusAcc(A, eps=1e-3, maxI=100):
    n = A.shape[0]
    x = np.ones(n) / n
    eig = (x.T) @ A @ x
    
    fin = 0
    i = 0
    eig0 = 0.
    eig1 = 0.
    while not fin:
        print('{:2d}: eig={}, x={}'.format(i, eig, x))
        xold = x.copy()
        eigold = eig * 1.
        y = A @ x
        x = y / np.sqrt((y**2).sum())
        eig2 = (x.T) @ A @ x
        eig = eig0 - ((eig1 - eig0)**2 / (eig2 - 2.*eig1 + eig0))
        eig0 = eig1 * 1.
        eig1 = eig2 * 1.
        if ((np.abs(eig-eigold) < eps) or (i >= maxI)):
        #if ((np.linalg.norm(x-xold, 1) < eps) or (i >= maxI)):
            fin = 1
        i += 1
    print(i, end=' ', flush=None)
    return eig, x



def frobeniusAcc2(A, eps=1e-3, maxI=100):
    n = A.shape[0]
    x = np.ones(n) / n
    eig = (x.T) @ A @ x
    
    fin = 0
    i = 0
    eig0 = 0.
    eig1 = 0.
    while not fin:
        xold = x.copy()
        eigold = eig * 1.
        y = A @ x
        x = y / np.sqrt((y**2).sum())
        eig2 = (x.T) @ A @ x
        eig = eig0 - ((eig1 - eig0)**2 / (eig2 - 2.*eig1 + eig0))
        eig0 = eig1 * 1.
        eig1 = eig2 * 1.
        if ((np.abs(eig-eigold) < eps) or (i >= maxI)):
        #if ((np.linalg.norm(x-xold, 1) < eps) or (i >= maxI)):
            fin = 1
        i += 1
    print(i, end=' ', flush=None)
    return eig, x



def powerI(A, eps=1e-3, maxI=100):
    n = A.shape[0]
    eigs = np.zeros(n)
    Q = np.zeros(A.shape)
    B = A.copy()
    
    for i in range(0, n):
        eig, q = frobenius2(B, eps, maxI)
        eigs[i] = eig
        Q[:,i] = q
        qq = q.reshape(n,1)
        B = B - eig*(qq @ qq.T)
    return eigs, Q



def powerAcc(A, eps=1e-3, maxI=100):
    n = A.shape[0]
    eigs = np.zeros(n)
    Q = np.zeros(A.shape)
    B = A.copy()
    
    for i in range(0, n):
        eig, q = frobeniusAcc2(B, eps, maxI)
        eigs[i] = eig
        Q[:,i] = q
        qq = q.reshape(n,1)
        B = B - eig*(qq @ qq.T)
    return eigs, Q
