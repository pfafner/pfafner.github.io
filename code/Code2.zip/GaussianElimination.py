import numpy as np
from scipy import linalg as lg


def gaussianReduction(A):
    m, n = A.shape
    if (m != n):
        raise Exception('matrix is not square')
    else:
        U = A.copy()
        L = np.eye(n)
        P = np.eye(n)
        sign = 1
    
        for j in range(0, n-1):
            #print('Paso columna {}: \n'.format(j+1))
            for i in range(j+1, n):
                if (U[j,j] == 0):
                    if (U[j+1:n,j].sum() != 0.):
                        k = j+1 + np.argwhere(U[j+1:n,j] != 0.)[0][0]
                        U[[j,k],:] = U[[k,j],:]
                        P[[j,k],:] = P[[k,j],:]
                        sign = -sign
                
                if (U[j,j] != 0.):
                    L[i,j] = U[i,j] / U[j,j]
                    U[i,j:n] = U[i,j:n] - L[i,j]*U[j,j:n]
                #print(L, end='\n\n')
                #print(U, end='\n\n')
    return P, L, U, sign


def Determinante(A):
    m, n = A.shape
    if (m != n):
        raise Exception('matrix is not square')
    else:
        _, _, U, sign = gaussianReduction(A)
        
        det = 1.*sign
        for i in range(0, n):
            det *= U[i,i]
    return det



def GaussJordan(A):
    m, n = A.shape
    U = A.copy()
    L1 = np.eye(m)
    P1 = np.eye(m)
    L2 = np.eye(m)
    P2 = np.eye(m)
    sign = 1

    # first stage
    #print('Primera Etapa. \n')
    for j in range(0, m-1):
        #print('Paso columna {}: \n'.format(j+1))
        for i in range(j+1, m):
            if (U[j,j] == 0):
                if (U[j+1:m,j].sum() != 0.):
                    k = j+1 + np.argwhere(U[j+1:m,j] != 0.)[0][0]
                    U[[j,k],:] = U[[k,j],:]
                    P1[[j,k],:] = P1[[k,j],:]
                    sign = -sign

            if (U[j,j] != 0.):
                L1[i,j] = U[i,j] / U[j,j]
                U[i,j:] = U[i,j:] - L1[i,j]*U[j,j:]
            #print(L1, end='\n\n')
            #print(U, end='\n\n')

    # diagonal
    for j in range(0, m):
        if (U[j,j] != 0.):
            L1[j,j] = 1. / U[j,j]
            U[j,:] = U[j,:] / U[j,j]
        
    # second stage
    #print('Segunda Etapa. \n')
    for j in range(1, m)[::-1]:
        #print('Paso columna {}: \n'.format(j+1))
        for i in range(0, j):
            if (U[j,j] == 0):
                if (U[0:j,j].sum() != 0.):
                    k = np.argwhere(U[0:j,j] != 0.)[0][0]
                    U[[j,k],:] = U[[k,j],:]
                    P2[[j,k],:] = P2[[k,j],:]
                    sign = -sign

            if (U[j,j] != 0.):
                L2[i,j] = U[i,j] / U[j,j]
                U[i,:] = U[i,:] - L2[i,j]*U[j,:]
            #print(L2, end='\n\n')
            #print(U, end='\n\n')

    return U



def Inversa(A):
    m, n = A.shape
    if (m != n):
        raise Exception('matrix is not square')
    elif (Determinante(A) == 0):
        raise Exception('matrix is not invertible')
    else:
        I = np.eye(n)
        Aext = np.hstack([A,I])
        U = GaussJordan(Aext)
        invA = U[:,n:]
    return invA



def SolveAxb(A, b):
    m, n = A.shape
    if (m != n):
        raise Exception('matrix is not square')
    elif (Determinante(A) == 0):
        raise Exception('matrix is not invertible')
    elif (len(b) != n):
        raise Exception('A and b shapes don\'t match')
    else:
        Aext = np.hstack([A,b.reshape(n,1)])
        U = GaussJordan(Aext)
        x = U[:,-1]
    return x